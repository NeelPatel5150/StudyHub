document.addEventListener("DOMContentLoaded", function () {
    const enrollButtons = document.querySelectorAll(".enroll-btn");
    const loginModal = document.getElementById("login-modal");
    const closeLoginModal = document.getElementById("close-login-modal");

    const nextStepBtn = document.getElementById("next-step");
    const paymentModal = document.getElementById("payment-modal");
    const closePaymentModal = document.getElementById("close-payment-modal");

    const proceedPaymentBtn = document.querySelector(".proceed-payment-btn");
    const paymentSuccessModal = document.getElementById("payment-success-modal");
    const closePaymentSuccess = document.querySelector("[data-close='payment-success-modal']");

    // Enroll Button Click - Show Login Modal
    enrollButtons.forEach(button => {
        button.addEventListener("click", function () {
            loginModal.style.display = "flex";
            setTimeout(() => loginModal.classList.add("show"), 10);
        });
    });

    // Close Login Modal
    closeLoginModal.addEventListener("click", function () {
        loginModal.classList.remove("show");
        setTimeout(() => (loginModal.style.display = "none"), 300);
    });

    // Next Step - Show Payment Modal
    nextStepBtn.addEventListener("click", function (event) {
        event.preventDefault();

        if (document.getElementById("login-form").checkValidity()) {
            loginModal.classList.remove("show");
            setTimeout(() => (loginModal.style.display = "none"), 300);

            paymentModal.style.display = "flex";
            setTimeout(() => paymentModal.classList.add("show"), 10);
        } else {
            document.getElementById("login-form").reportValidity();
        }
    });

    // Close Payment Modal
    closePaymentModal.addEventListener("click", function () {
        paymentModal.classList.remove("show");
        setTimeout(() => (paymentModal.style.display = "none"), 300);
    });

    // Proceed to Payment - Show Success Modal
    proceedPaymentBtn.addEventListener("click", function (event) {
        event.preventDefault(); // Prevent accidental form submission

        if (document.getElementById("payment-form").checkValidity()) {
            paymentModal.classList.remove("show");
            setTimeout(() => (paymentModal.style.display = "none"), 300);

            paymentSuccessModal.style.display = "flex";
            setTimeout(() => paymentSuccessModal.classList.add("show"), 10);
        } else {
            document.getElementById("payment-form").reportValidity();
        }
    });

    // Close Payment Success Modal
    closePaymentSuccess.addEventListener("click", function () {
        paymentSuccessModal.classList.remove("show");
        setTimeout(() => (paymentSuccessModal.style.display = "none"), 300);
    });
});
