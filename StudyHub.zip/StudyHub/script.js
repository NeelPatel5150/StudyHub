function toggleMenu() {
    const nav = document.querySelector(".nav-links");
    nav.classList.toggle("show");
}

// Scroll Animation for Sections
document.addEventListener("DOMContentLoaded", function () {
    const sections = document.querySelectorAll("section");

    const revealSection = () => {
        sections.forEach(section => {
            const sectionTop = section.getBoundingClientRect().top;
            const triggerPoint = window.innerHeight - 100;
            if (sectionTop < triggerPoint) {
                section.classList.add("visible");
            }
        });
    };

    window.addEventListener("scroll", revealSection);
    revealSection(); // Run initially
});

// Back To Top Button
window.addEventListener("scroll", function () {
    document.getElementById("backToTop").style.display = window.scrollY > 300 ? "block" : "none";
});

document.addEventListener("DOMContentLoaded", function () {
    const backToTop = document.getElementById("backToTop");

    window.addEventListener("scroll", function () {
        if (window.scrollY > 300) {
            backToTop.style.display = "block"; // Show button
        } else {
            backToTop.style.display = "none"; // Hide button
        }
    });

    // Scroll to top function
    backToTop.addEventListener("click", function () {
        window.scrollTo({
            top: 0,
            behavior: "smooth" // Smooth scrolling effect
        });
    });
});

// FAQ Accordion Section
document.addEventListener("DOMContentLoaded", function () {
    const faqButtons = document.querySelectorAll(".faq-btn");

    faqButtons.forEach((btn) => {
        btn.addEventListener("click", function () {
            const faq = this.parentElement;
            faq.classList.toggle("active");

            // Close other open FAQs
            document.querySelectorAll(".faq").forEach((item) => {
                if (item !== faq) {
                    item.classList.remove("active");
                }
            });
        });
    });
});

function enrollCourse() {
    alert("You have successfully enrolled in this course!");
}


/* ========================= FOR SMOOTH OPEN COURSE.HTML PAGE========================== */

document.getElementById('exploreBtn').addEventListener('click', function (event) {
    event.preventDefault();  // Prevent the default link behavior

    // Add fade-out effect to the body or hero section
    document.querySelector('body').classList.add('fade-out');

    // After the fade-out animation ends, redirect to course.html
    setTimeout(function () {
        window.location.href = 'course.html';  // Redirect after fade-out effect
    }, 1000);  // Delay to match the fade-out duration
});


/* ======================================================================================= */

document.getElementById("login").addEventListener("click", function() {
    window.location.href = "login.html"; // Redirects to the login page
});

